# Version: v1.1

# v1.1
# - die Trendwerte hatten falscher Index