"""
    Eine Reihe von Module zur Verwendung bei der Explorative Analyse
    Menu- Verfahren in Terminal

"""