
### Flaubert

Eine Ansammlung von Skripte für verschiedene Operationen für Datenverarbeitung und Modellierung
